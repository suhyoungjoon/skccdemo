package com.mycom.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycom.board.dto.BoardDto;
import com.mycom.board.mapper.BoardMapper;

@Service
public class BoardService {

	@Autowired
	private BoardMapper boardMapper;
	
	public void insertBoard(BoardDto dto) {
		boardMapper.insertBoard(dto);
	}

	public List<BoardDto> selectBoardList() {
		return boardMapper.selectBoardList();
	}

	public BoardDto selectBoardDetail(int boardIdx) {
		boardMapper.updateHitCount(boardIdx); // 조회수 증가
		return boardMapper.selectBoardDetail(boardIdx);
	}

	public void updateBoard(BoardDto dto) {
		boardMapper.updateBoard(dto);
	}

	public void deleteBoard(int boardIdx) {
		boardMapper.deleteBoard(boardIdx);
	}
	
}
