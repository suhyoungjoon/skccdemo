package com.mycom.board.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mycom.board.dto.BoardDto;

@Mapper
public interface BoardMapper {
	public void insertBoard(BoardDto dto);
	public List<BoardDto> selectBoardList();
	public BoardDto selectBoardDetail(int boardIdx);
	public void updateBoard(BoardDto dto);
	public void deleteBoard(int boardIdx);
	public void updateHitCount(int boardIdx);
}
