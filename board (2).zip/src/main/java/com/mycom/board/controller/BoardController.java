package com.mycom.board.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mycom.board.dto.BoardDto;
import com.mycom.board.service.BoardService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping("/board")
public class BoardController {
	// /board/openBoardWrite     글쓰기 화면 , HTML
	// /board/insertBoard, POST  글 저장     , C(insert)
	// /board/openBoardList      글 리스트   , R(Read : select)
	// /board/openBoardDetail/7  글 하나 보기, R(Read : select)
	// /board/updateBoard, POST  글 수정     , U(update)
	// /board/deleteBoard, POST  글 삭제     , D(delete)

	@Autowired
	private BoardService boardService;

	// localhost:8080/board/openBoardWrite
	@GetMapping("/openBoardWrite")
	public String openBoardWrite() {
		return "/board/boardWrite";
	}

	// localhost:8080/board/insertBoard, POST
	@PostMapping("/insertBoard")
	public String insertBoard(BoardDto dto) {
		boardService.insertBoard(dto);
		// return "/board/temp"; // 게시판 리스트를 아직 안만들어서 임시로 /board/temp 사용
		return "redirect:/board/openBoardList";
	}

	// localhost:8080/board/openBoardList
	@GetMapping("/openBoardList")
	public String openBoardList(Model model) {
		List<BoardDto> list = boardService.selectBoardList();
		model.addAttribute("list", list); // 키 : 값
		return "/board/boardList"; // boardList.jsp
	}

	// localhost:8080/board/openBoardDetail/7 예
	@GetMapping("/openBoardDetail/{boardIdx}")
	public String openBoardDetail(@PathVariable("boardIdx") int boardIdx, Model model) {
		BoardDto dto = boardService.selectBoardDetail(boardIdx);
		log.info("dto=" + dto);
		model.addAttribute("b", dto);
		return "/board/boardDetail";
	}
	
	// localhost:8080/board/updateBoard, POST
	@PostMapping("/updateBoard")
	public String updateBoard(BoardDto dto) {
		log.info("updateBoard 호출 성공!");
		boardService.updateBoard(dto);
		return "redirect:/board/openBoardList";
	}
	
	// localhost:8080/board/deleteBoard, POST
	@PostMapping("/deleteBoard")
	public String deleteBoard(int boardIdx) {
		log.info("boardIdx=" + boardIdx);
		boardService.deleteBoard(boardIdx);
		// return "/board/temp";
		return "redirect:/board/openBoardList";
	}

}// end


