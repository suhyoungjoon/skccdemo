package com.mycom.board.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BoardDto {
	private int boardIdx;
	private String title;
	private String contents;
	private int hitCnt;
	private String createdDatetime;
	private String creatorId;
	private String updatedDatetime;
	private String updaterId;
	private String deletedYn;
}

/*
CREATE TABLE t_board(
    board_idx INT NOT NULL AUTO_INCREMENT,
    title VARCHAR(300) NOT NULL,
    contents TEXT NOT NULL,
    hit_cnt SMALLINT NOT NULL DEFAULT 0,
    created_datetime DATETIME NOT NULL DEFAULT NOW(),
    creator_id VARCHAR(50) NOT NULL,
    updated_datetime DATETIME,
    updater_id VARCHAR(50),
    deleted_yn CHAR(1) NOT NULL DEFAULT 'N',
    PRIMARY KEY(board_idx)
);
*/
